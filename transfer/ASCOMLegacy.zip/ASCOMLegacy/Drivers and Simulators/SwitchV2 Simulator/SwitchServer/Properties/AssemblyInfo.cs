﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ASCOM SwitchServer server")]
[assembly: AssemblyDescription("ASCOM multi-interface server for SwitchServer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ASCOM Initiative")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright © ASCOM Initiative 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisibleAttribute(false)]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("6.6.0.0")]
