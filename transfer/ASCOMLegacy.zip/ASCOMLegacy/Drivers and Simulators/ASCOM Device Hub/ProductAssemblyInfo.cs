﻿using System.Reflection;

// General Information about an assembly is controlled through the following
// set of attributes. 

// Changing the AssemblyCompany and the AssemblyProduct will change the location and name
// of the application settings xml file.

[assembly: AssemblyCompany( "The ASCOM Initiative" )]
[assembly: AssemblyCopyright("Copyright © ASCOM Initiative 2022")]
[assembly: AssemblyTrademark( "" )]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion( "6.6.1.3" )]