﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for DomeCapabilitiesView.xaml
    /// </summary>
    public partial class DomeCapabilitiesView : UserControl
	{
		public DomeCapabilitiesView()
		{
			InitializeComponent();
		}
	}
}
