﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for DomeSetupView.xaml
    /// </summary>
    public partial class DomeSetupView : UserControl
	{
		public DomeSetupView()
		{
			InitializeComponent();
		}
	}
}
