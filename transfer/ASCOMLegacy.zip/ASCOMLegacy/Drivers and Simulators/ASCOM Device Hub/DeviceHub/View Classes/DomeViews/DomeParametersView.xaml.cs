﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for DomeParametersView.xaml
    /// </summary>
    public partial class DomeParametersView : UserControl
	{
		public DomeParametersView()
		{
			InitializeComponent();
		}
	}
}
