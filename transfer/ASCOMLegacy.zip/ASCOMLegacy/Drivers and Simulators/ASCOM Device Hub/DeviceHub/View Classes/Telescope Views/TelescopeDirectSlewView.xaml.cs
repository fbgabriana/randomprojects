﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for TelescopeDirectSlewView.xaml
    /// </summary>
    public partial class TelescopeDirectSlewView : UserControl
	{
		public TelescopeDirectSlewView()
		{
			InitializeComponent();
		}
	}
}
