﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for TelescopeSetupView.xaml
    /// </summary>
    public partial class TelescopeSetupView : UserControl
    {
        public TelescopeSetupView()
        {
            InitializeComponent();
        }
    }
}
