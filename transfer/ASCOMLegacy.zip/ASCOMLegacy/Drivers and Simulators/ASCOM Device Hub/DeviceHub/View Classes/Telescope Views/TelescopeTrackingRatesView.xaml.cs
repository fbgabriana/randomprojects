﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for TelescopeTrackingRatesView.xaml
    /// </summary>
    public partial class TelescopeTrackingRatesView : UserControl
	{
		public TelescopeTrackingRatesView()
		{
			InitializeComponent();
		}
	}
}
