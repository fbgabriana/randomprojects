﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for TelescopeParametersView.xaml
    /// </summary>
    public partial class TelescopeParametersView : UserControl
	{
		public TelescopeParametersView()
		{
			InitializeComponent();
		}
	}
}
