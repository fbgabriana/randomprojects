﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for TelescopeCapabilitiesView.xaml
    /// </summary>
    public partial class TelescopeCapabilitiesView : UserControl
	{
		public TelescopeCapabilitiesView()
		{
			InitializeComponent();
		}
	}
}
