﻿namespace ASCOM.DeviceHub
{
	/// <summary>
	/// Interaction logic for AboutWindow.xaml
	/// </summary>
	public partial class AboutView : DeviceHubDialogView
	{
		public AboutView()
		{
			InitializeComponent();
		}
	}
}
