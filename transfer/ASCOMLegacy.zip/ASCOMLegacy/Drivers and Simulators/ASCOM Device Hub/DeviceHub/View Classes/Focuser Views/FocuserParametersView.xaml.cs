﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for FocuserParametersView.xaml
    /// </summary>
    public partial class FocuserParametersView : UserControl
    {
        public FocuserParametersView()
        {
            InitializeComponent();
        }
    }
}
