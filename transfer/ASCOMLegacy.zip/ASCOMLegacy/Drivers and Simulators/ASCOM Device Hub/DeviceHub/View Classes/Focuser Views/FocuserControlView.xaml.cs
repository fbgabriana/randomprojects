﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for FocuserControlView.xaml
    /// </summary>
    public partial class FocuserControlView : UserControl
    {
        public FocuserControlView()
        {
            InitializeComponent();
        }
    }
}
