﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for FocuserSetupView.xaml
    /// </summary>
    public partial class FocuserSetupView : UserControl
	{
		public FocuserSetupView()
		{
			InitializeComponent();
		}
	}
}
