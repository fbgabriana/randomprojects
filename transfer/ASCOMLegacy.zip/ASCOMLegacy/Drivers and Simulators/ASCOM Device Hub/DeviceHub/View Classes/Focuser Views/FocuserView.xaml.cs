﻿using System.Windows.Controls;

namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for FocuserView.xaml
    /// </summary>
    public partial class FocuserView : UserControl
    {
        public FocuserView()
        {
            InitializeComponent();
        }
    }
}
