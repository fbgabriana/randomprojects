﻿namespace ASCOM.DeviceHub
{
    /// <summary>
    /// Interaction logic for FocuserDriverSetupDialogView.xaml
    /// </summary>
    public partial class FocuserDriverSetupDialogView : DeviceHubDialogView
	{
		public FocuserDriverSetupDialogView()
		{
			InitializeComponent();
		}
	}
}
