﻿using System;

namespace ASCOM.DeviceHub
{
    class DisplayAttribute : Attribute
	{
		public string Name { get; set; }
	}
}
