﻿namespace ASCOM.DeviceHub
{
	public class FocuserMoveCompletedMessage
    {
		public FocuserMoveCompletedMessage()
		{}
    }
}
