﻿namespace ASCOM.DeviceHub
{
	public class ActivityLogClosedMessage
    {
		public ActivityLogClosedMessage()
		{

		}
    }
}
