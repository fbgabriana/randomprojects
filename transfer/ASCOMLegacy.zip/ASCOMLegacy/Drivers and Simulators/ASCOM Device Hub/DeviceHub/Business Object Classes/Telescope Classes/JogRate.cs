﻿namespace ASCOM.DeviceHub
{
	public class JogRate
	{
		public string Name { get; set; }
		public double Rate { get; set; }
	}
}
