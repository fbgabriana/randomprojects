﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ASCOM.Simulator.Focuser")]
[assembly: AssemblyDescription("ASCOM Focuser Simulator Driver")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © ASCOM Initiative 2022")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(true)]
[assembly: CLSCompliant(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("5FC578AC-C7E2-4F02-9478-BD459DC4981F")]

// AssemblyFileVersion is set globally (do not add an AssemblyFileVersion here).
[assembly: AssemblyVersion("6.6.0.0")]

