You must have ASCOM platform 5 installed to build this software.

For fast updates after rebuilds, double click the register.bat file
