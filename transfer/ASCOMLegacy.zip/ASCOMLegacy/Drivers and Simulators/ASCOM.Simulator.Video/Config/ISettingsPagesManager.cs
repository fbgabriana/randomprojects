﻿using ASCOM.Simulator.Properties;

namespace ASCOM.Simulator.Config
{
    public interface ISettingsPagesManager
	{
		void CameraTypeChanged(SimulatedCameraType cameraType);
	}
}
