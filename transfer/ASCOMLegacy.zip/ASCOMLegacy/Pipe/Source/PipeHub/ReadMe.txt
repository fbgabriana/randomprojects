You must have ASCOM platform 5 installed to build this software.

Be sure to use PipeHub.vbg to drive visual Basic as this is a group build.

For fast updates after rebuilds, double click the register.bat file
